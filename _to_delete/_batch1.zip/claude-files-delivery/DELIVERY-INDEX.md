# Sidra OS — Architecture Delivery Index (living)

**The running index of every architecture delivery package.** Updated as each milestone is delivered. The
authoritative definition of every milestone is `/MILESTONE_REGISTRY.md`; where this index disagrees, the
registry governs.

| | |
|---|---|
| Programme | M1 – M30 |
| Documented (architecture + plan) | M1 – M20 |
| Remaining to architect | M21 – M30 (3.0 "Chambers", 4.0 "Continuum") |
| Scope of the delivery-package backfill | M10 – M30 (M15 architecture lives in `docs-v2/03-Intelligence/`; M16 was delivered earlier) |
| Standard | Architecture + specification only — no production code |

---

## 1. Status by release

### 1.0 "Atrium" — M1–M10
M1–M9 are documented in `/docs`. **M10 (Hardening & 1.0)** has a delivery package: `M10-hardening-and-1.0/`.

### 2.0 "Concourse" — M11–M15
Delivery packages: `M11-department-substrate/`, `M12-structure/`, `M13-departments/`,
`M14-game-studio-and-marketplace/`. **M15 (Mission Engine)** architecture + 113-task plan live in
`docs-v2/03-Intelligence/` (complete; not repackaged).

### 2.5 "Field" — M16–M20
`M16-connector-framework/` (delivered earlier, + `M16-VERIFICATION-AUDIT.md`). **New in this pass:**
`M17-first-party-connector-suite/`, `M18-companion/`, `M19-voice-directive/`, `M20-executable-artifacts/`.

### 3.0 "Chambers" — M21–M25 · 4.0 "Continuum" — M26–M30
**Pending** — being produced sequentially.

## 2. Delivery-package inventory (this pass)

| M | Package | Exit criterion | Arch size |
|---|---|---|---|
| M10 | `M10-hardening-and-1.0/` | 30 days dogfood, zero data loss, zero unlogged effects | 56 KB |
| M11 | `M11-department-substrate/` | Replay-equivalence green; one implicit department, byte-identical | 54 KB |
| M12 | `M12-structure/` | 8 Divisions, 4 Offices, Rail shows Divisions, veto blocks firm-wide | 62 KB |
| M13 | `M13-departments/` | Three Packs install; one Exchange request end to end | 64 KB |
| M14 | `M14-game-studio-and-marketplace/` | Nine-item list incl. uninstall-leaves-Firm-working | 66 KB |
| M17 | `M17-first-party-connector-suite/` | Five connectors pass conformance; per-dept grantable; offline-safe | 65 KB |
| M18 | `M18-companion/` | Clear a day's approvals from a phone with no desktop; Brief renders identically | 63 KB |
| M19 | `M19-voice-directive/` | Spoken Directive → same Mandate as typed; audio never leaves the device | 65 KB |
| M20 | `M20-executable-artifacts/` | Agent-authored artifact executes, capability-bounded ≤ its Work Order grant | 65 KB |

Each package contains: `README`, `00-M{n-1}-AUDIT` (STEP-1 gate), architecture spec, `IMPLEMENTATION_PLAN`
(epics → tasks → subtasks), `REVIEW_CHECKLIST`, and `adr/`.

## 3. ADR map (contiguous, continuing after the repo's 0037)

| Range | Milestone(s) | Count |
|---|---|---|
| 0038–0039 | M10 | 2 |
| 0040–0041 | M11 | 2 |
| 0042 | M12 | 1 |
| 0043–0044 | M13 | 2 |
| 0045 | M14 | 1 |
| 0046–0048 | M17 | 3 |
| 0049–0051 | M18 | 3 |
| 0052–0053 | M19 | 2 |
| 0054–0056 | M20 | 3 |
| 0057+ | M21–M30 | pending |

All `Proposed`; become `Accepted` on Principal approval. (0038–0044 are already merged into
`docs-v2/adr/README.md`; 0045+ pending integration.)

## 4. Migration map (forward-only; below nothing already committed)

| Band | Owner |
|---|---|
| `0001` | v1 base (M2–M9) |
| `0002`–`0006` | M11 · `0007`–`0010` M12 · `0011`–`0015` M13 (files present in repo) |
| `0016`–`0018` | M14 (pending integration) |
| `0019`–`0024` | M15 · `0025`–`0029` M16 (V25–V29 committed) |
| `0030` | M17 (`connector_conformance`) |
| `0033`–`0036` | M18 (companion devices, sync, approval outbox, brief cache) |
| `0037`–`0038` | M19 (directive input method, voice captures) |
| `0039`–`0041` | M20 (executable artifacts, artifact grants, artifact runs) |
| `0042`+ | M21–M30 pending |

Migration numbers are compacted to a contiguous sequence in the final consistency pass once M30 is delivered.

## 5. Build order (2.5 "Field")

```
M16 framework ─► M17 connector suite ─► M18 companion ─► M19 voice ─► M20 executable artifacts ─► 2.5 ships
                 (five artifacts on      (read Briefs +   (local STT   (agent-authored, capability-
                  the M16 framework)      act approvals)   → Directive)  bounded ≤ Work Order grant)
```

Registry dependencies: M17→M16; M18→M10+M15; M19→M18+M6; M20→M9+M16.

## 6. What remains

**M21–M30** — 3.0 "Chambers" (Seats, Separation of Duties, Kernel Extraction, Sync, Firm Templates) and
4.0 "Continuum" (Outcome Calibration, Charter Evolution, Procedural Compilation, Firm Self-Review, Continuum
Hardening). On completion this index is finalized alongside a dependency map, an implementation roadmap, and a
full architecture completeness audit.
